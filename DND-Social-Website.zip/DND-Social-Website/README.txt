DND Social — consolidated website starter

DEPLOY ON NETLIFY
1. Upload index.html to the root of your GitHub repository.
2. Connect that repository to Netlify and deploy it. The homepage file must be named exactly index.html.
3. Open your Netlify URL and test navigation, post creation, likes, follows, profile settings, search, and export.

WHAT WORKS IN THIS STARTER
- Responsive DND Social interface and navigation
- Local post creation, likes, reply prompts, sharing, and search
- Sample people/following UI and local profile settings
- Video preview from public direct media URLs
- Demo dashboard, data export/reset, and links to payment-provider websites

IMPORTANT LIMITATIONS
This is a front-end prototype. Posts/follows/profile are stored in the current browser only. It does not yet provide real multi-user accounts, cross-device shared posts, real private messaging, live video broadcasting, secure payment collection, creator balances, or bank withdrawals. Those require backend/database rules, authentication, media storage, a streaming provider, and a payment provider's approved server-side integration.

The earlier “DataCloneError ... Headers object could not be cloned” message is not present in this HTML file. If it appears only inside Claude's preview, it may be caused by the preview environment or a library used there. This copy does not claim to fix Claude's preview internals.
