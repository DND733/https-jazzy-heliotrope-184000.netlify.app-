# DND Social connected starter

This package is a starting point for a real community website. It includes a responsive interface and Supabase integration for email/password accounts, profiles, posts, likes, comments, follows, creator activity counts, and marketplace listings.

IMPORTANT: It cannot be fully live until you configure a Supabase project. Live broadcasting requires a streaming provider plus a secure server for room tokens. Marketplace checkout and creator payouts require payment-provider onboarding and secure server-side code. Never put secret/service-role keys in browser files.

## Setup
1. Open https://supabase.com/dashboard and create/open a project.
2. In SQL Editor, run all of `supabase-setup.sql`.
3. In Storage, create a bucket named `social-media`. For this demo it is public; do not upload private/sensitive media. Configure authenticated upload policies so the first folder segment equals the signed-in user's ID.
4. In Project Settings → API, copy the Project URL and the public publishable/anon key.
5. Open `app.js` and replace the two `PASTE_...` values. Do not use the service_role/secret key.
6. Upload `index.html`, `styles.css`, and `app.js` to your existing GitHub repository / Netlify site. Keep `supabase-setup.sql` and this README for setup.
7. In Supabase Authentication URL Configuration, add your exact Netlify URL as Site URL and redirect URL.
8. Test sign-up, text posts, likes, comments, follows, and product listings. Then configure media storage.

## Included / not included
Included after setup: shared email/password accounts, profiles, text/photo/video posts, likes, comments, follows, simple creator activity metrics, and product listings.
Not included yet: production livestreaming, checkout/payments, delivery management, creator payouts/ad monetization, direct messages, push notifications, video transcoding, advanced moderation, and security audit. Those require additional services and server-side implementation. This is not a production-scale TikTok clone yet.
