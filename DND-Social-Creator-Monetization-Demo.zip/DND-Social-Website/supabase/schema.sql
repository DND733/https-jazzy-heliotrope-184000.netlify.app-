-- Run this in Supabase SQL Editor. The table records payment events; it is NOT a wallet ledger.
create table if not exists public.dnd_payments (
  reference text primary key,
  amount_kobo bigint not null check (amount_kobo > 0),
  currency text not null check (currency = 'NGN'),
  status text not null check (status in ('success')),
  customer_email text not null,
  channel text,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

-- Keep direct client access blocked. Only the server-side service-role key should write/read this table.
alter table public.dnd_payments enable row level security;
revoke all on table public.dnd_payments from anon, authenticated;
