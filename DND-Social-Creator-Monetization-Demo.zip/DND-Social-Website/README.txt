DND SOCIAL + PAYSTACK — INTEGRATION STARTER
===========================================

WHAT IS INCLUDED
- index.html: existing DND Social front-end with Paystack checkout starter UI.
- netlify/functions/paystack-initialize.mjs: server-side checkout initialization. Allows only the displayed ₦500/₦1,000/₦2,000 amounts.
- netlify/functions/paystack-verify.mjs: server-side verification of callback references.
- netlify/functions/paystack-webhook.mjs: signature-checking webhook that records successful Paystack events in Supabase.
- supabase/schema.sql: locked-down payment-record table.
- payment-result.html: checks the transaction status with the backend.
- netlify.toml: Netlify publish/function settings.

IMPORTANT STATUS
This is an integration starter, not a claim that Paystack is already connected or live. You must create the Paystack business account, complete approval, configure credentials and deploy the files. Test mode is the default. Never add a secret key to index.html or commit it to GitHub.

SETUP STEPS (Android-friendly)
1. Create a Paystack business account at https://dashboard.paystack.com/ and complete the onboarding honestly with the appropriate business owner/guardian. Keep it in test mode while developing.
2. In Supabase, open SQL Editor and run supabase/schema.sql.
3. In the GitHub repository used by Netlify, upload/replace index.html and add these files/folders exactly: netlify.toml, payment-result.html, netlify/functions/paystack-initialize.mjs, netlify/functions/paystack-verify.mjs, netlify/functions/paystack-webhook.mjs, supabase/schema.sql. Keep index.html at repository root.
4. In Netlify > Site configuration > Environment variables, add:
   PAYSTACK_SECRET_KEY = test secret key from Paystack (for testing only)
   SUPABASE_URL = your Supabase project URL
   SUPABASE_SERVICE_ROLE_KEY = Supabase service-role key (server-side only)
   Do not share these values in chat or place them in browser code. Redeploy after setting them.
5. In Paystack dashboard, configure webhook URL to:
   https://YOUR-NETLIFY-SITE/.netlify/functions/paystack-webhook
   Replace YOUR-NETLIFY-SITE with your actual deployed host. Use HTTPS.
6. Test using Paystack's test mode and test credentials from its official docs. Confirm a signed webhook inserts one row in public.dnd_payments and that a duplicate webhook does not create duplicates.
7. Only after the business is approved, change to live credentials securely in Netlify environment variables and run a small real transaction. Never test with money you cannot afford to lose.

CREATOR EARNINGS / WITHDRAWALS
This starter intentionally does NOT enable creator withdrawals or treat incoming tips as creator earnings. A payment row is not a creator balance. Before withdrawals, implement authenticated user identities, order/creator mapping, an immutable double-entry ledger, refunds/chargeback handling, payout approvals, recipient verification, rate limits, audit logs, and a compliant payout provider setup. Paystack transfers may require an eligible registered business and approval. Do not call a withdrawal endpoint until the business is approved and these controls are tested. Consider Paystack split payments for marketplace seller settlement after checking eligibility and the correct model in Paystack's docs.

SECURITY NOTES
- Secret keys only in Netlify environment variables.
- Never collect bank PIN, card PIN, OTP, or online banking passwords on DND.
- Browser redirects are not proof of payment; verify server-side and rely on signed webhooks.
- Table access is blocked for anon/authenticated users by the included SQL; the service-role key bypasses RLS and must remain server-only.
- Current DND app still uses local browser demo data for posts/profiles; this package does not turn it into a multi-user social network, real chat, or real live streaming platform.

OFFICIAL REFERENCES
Paystack payments: https://paystack.com/docs/payments/
Paystack verify payments: https://paystack.com/docs/payments/verify-payments/
Paystack webhooks: https://paystack.com/docs/payments/webhooks/
Paystack split payments: https://paystack.com/docs/payments/split-payments/
Paystack transfers: https://paystack.com/docs/transfers/
Paystack activation: https://support.paystack.com/en/articles/2125506
