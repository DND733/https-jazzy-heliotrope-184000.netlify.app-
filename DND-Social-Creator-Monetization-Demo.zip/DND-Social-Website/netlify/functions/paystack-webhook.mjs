// Paystack webhook: validates the signature, then records successful transactions in Supabase.
// Configure PAYSTACK_SECRET_KEY, SUPABASE_URL, and SUPABASE_SERVICE_ROLE_KEY in Netlify.
import crypto from "node:crypto";
export default async (request) => {
  if (request.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const secret = process.env.PAYSTACK_SECRET_KEY;
  const supabaseUrl = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!secret || !supabaseUrl || !serviceKey) return new Response("Webhook not configured", { status: 503 });
  const raw = await request.text();
  const supplied = request.headers.get("x-paystack-signature") || "";
  const expected = crypto.createHmac("sha512", secret).update(raw).digest("hex");
  const a = Buffer.from(supplied, "utf8"), b = Buffer.from(expected, "utf8");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return new Response("Invalid signature", { status: 401 });
  let event;
  try { event = JSON.parse(raw); } catch { return new Response("Invalid JSON", { status: 400 }); }
  if (event.event === "charge.success" && event.data?.reference) {
    const tx = event.data;
    // Server-side event is signed by Paystack; idempotent upsert is backed by unique reference.
    const row = { reference: String(tx.reference), amount_kobo: Number(tx.amount), currency: String(tx.currency || ""),
      status: "success", customer_email: String(tx.customer?.email || ""), channel: String(tx.channel || ""), paid_at: tx.paid_at || null };
    const result = await fetch(`${supabaseUrl.replace(/\/$/, "")}/rest/v1/dnd_payments?on_conflict=reference`, {
      method: "POST", headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}`, "Content-Type": "application/json",
        Prefer: "resolution=merge-duplicates,return=minimal" }, body: JSON.stringify(row)
    });
    if (!result.ok) return new Response("Database write failed", { status: 500 });
  }
  return new Response("ok", { status: 200 });
};
