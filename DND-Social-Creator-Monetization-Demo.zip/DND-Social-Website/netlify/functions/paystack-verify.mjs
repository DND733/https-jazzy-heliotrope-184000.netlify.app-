// Optional callback verification endpoint. Do not use the browser redirect alone as proof of payment.
export default async (request) => {
  const headers = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };
  const secret = process.env.PAYSTACK_SECRET_KEY;
  const url = new URL(request.url);
  const reference = url.searchParams.get("reference") || url.searchParams.get("trxref");
  if (!secret) return new Response(JSON.stringify({ error: "Paystack is not configured." }), { status: 503, headers });
  if (!reference || !/^dnd_[a-f0-9]{32}$/.test(reference)) return new Response(JSON.stringify({ error: "Invalid reference." }), { status: 400, headers });
  try {
    const r = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, { headers: { Authorization: `Bearer ${secret}` } });
    const result = await r.json();
    if (!r.ok || !result.status) return new Response(JSON.stringify({ status: "unverified" }), { status: 502, headers });
    const tx = result.data;
    return new Response(JSON.stringify({ status: tx.status === "success" && tx.currency === "NGN" ? "verified" : "not_successful",
      amount_kobo: tx.amount, currency: tx.currency, reference: tx.reference }), { status: 200, headers });
  } catch { return new Response(JSON.stringify({ status: "unverified" }), { status: 502, headers }); }
};
