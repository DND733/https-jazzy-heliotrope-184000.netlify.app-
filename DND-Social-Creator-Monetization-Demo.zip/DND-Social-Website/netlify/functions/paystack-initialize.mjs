// Netlify Function: creates a Paystack checkout session on the server.
// The secret key is read only from Netlify environment variables, never from browser code.
export default async (request) => {
  const headers = { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" };
  if (request.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers });
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return new Response(JSON.stringify({ error: "Paystack is not configured. Add PAYSTACK_SECRET_KEY in Netlify environment variables." }), { status: 503, headers });
  let body;
  try { body = await request.json(); } catch { return new Response(JSON.stringify({ error: "Invalid JSON" }), { status: 400, headers }); }
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const amountNaira = Number(body.amount);
  const allowedAmounts = new Set([500, 1000, 2000]);
  if (!/^\S+@\S+\.\S+$/.test(email) || !allowedAmounts.has(amountNaira)) {
    return new Response(JSON.stringify({ error: "Enter a valid email and choose one of the listed amounts." }), { status: 400, headers });
  }
  const siteUrl = process.env.URL || process.env.DEPLOY_PRIME_URL;
  if (!siteUrl) return new Response(JSON.stringify({ error: "Netlify site URL is missing." }), { status: 503, headers });
  const reference = `dnd_${crypto.randomUUID().replaceAll("-", "")}`;
  try {
    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
      body: JSON.stringify({ email, amount: String(amountNaira * 100), currency: "NGN", reference,
        callback_url: `${siteUrl}/payment-result.html`, metadata: { service: "dnd_creator_support", reference } })
    });
    const result = await response.json();
    if (!response.ok || !result.status || !result.data?.authorization_url) {
      return new Response(JSON.stringify({ error: "Paystack could not initialize checkout. Check business activation and test/live keys." }), { status: 502, headers });
    }
    return new Response(JSON.stringify({ authorization_url: result.data.authorization_url, reference }), { status: 200, headers });
  } catch {
    return new Response(JSON.stringify({ error: "Unable to reach Paystack. Try again later." }), { status: 502, headers });
  }
};
